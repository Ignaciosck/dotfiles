#!/bin/bash
Xvfb :99 -screen 0 1920x1200x24 -ac +extension GLX &
export DISPLAY=:99.0
exec "$@"